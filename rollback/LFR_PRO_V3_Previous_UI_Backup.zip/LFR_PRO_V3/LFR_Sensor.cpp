#include "LFR_Sensor.h"
namespace lfr {
void Sensor::begin() {
  pinMode(LFR_PIN_S0,OUTPUT);pinMode(LFR_PIN_S1,OUTPUT);
  pinMode(LFR_PIN_S2,OUTPUT);pinMode(LFR_PIN_S3,OUTPUT);
  pinMode(LFR_PIN_ADC,INPUT_ANALOG);
  analogReadResolution(12);
  resetTracking();
}
void Sensor::resetTracking() {
  hasFilter_=false;hasPosition_=false;lastPos_=0;
}
void Sensor::selectChannel(uint8_t channel) {
  digitalWrite(LFR_PIN_S0,(channel>>0)&1);
  digitalWrite(LFR_PIN_S1,(channel>>1)&1);
  digitalWrite(LFR_PIN_S2,(channel>>2)&1);
  digitalWrite(LFR_PIN_S3,(channel>>3)&1);
}
uint16_t Sensor::adcChannel(uint8_t channel) {
  selectChannel(channel);
  delayMicroseconds(20);  // MUX analog settling
  (void)analogRead(LFR_PIN_ADC); // discard first conversion after switching
  const int value=analogRead(LFR_PIN_ADC);
  return uint16_t(value<0?0:(value>ADC_MAX?ADC_MAX:value));
}
void Sensor::capture(uint16_t destination[SENSOR_COUNT]) {
  // Capture means with motors STOPPED and the entire sensor bar on ONE surface.
  uint32_t sums[SENSOR_COUNT]={};
  for(uint8_t j=0;j<48;++j) {
    for(uint8_t i=0;i<SENSOR_COUNT;++i)
      sums[i]+=adcChannel(MUX_BY_POSITION[i]);
    delay(2);
  }
  for(uint8_t i=0;i<SENSOR_COUNT;++i)
    destination[i]=uint16_t(sums[i]/48);
  resetTracking();
}
void Sensor::read(SensorFrame &f,const Calibration &cal,bool valid,const Settings &s) {
  uint32_t total=0;
  f.active=0;f.groups=0;
  f.center=false;f.leftEdge=false;f.rightEdge=false;
  f.fullMarker=false;f.junction=false;f.seen=false;f.confidence=0;
  for(uint8_t i=0;i<SENSOR_COUNT;++i) {
    const uint8_t src=s.mirror?uint8_t(SENSOR_COUNT-1-i):i;
    const uint16_t raw=adcChannel(MUX_BY_POSITION[src]);
    f.raw[i]=raw;
    uint16_t normalized=0;
    if(valid) {
      const int32_t range=int32_t(cal.black[src])-int32_t(cal.white[src]);
      int32_t black= range>0 ? (int32_t(raw)-int32_t(cal.white[src]))*1000L/range : 0;
      if(black<0)black=0;
      if(black>1000)black=1000;
      normalized=(s.lineMode==uint8_t(LineMode::Black))?uint16_t(black):uint16_t(1000-black);
    }
    // 75% current, 25% previous. Quick enough for corners, cuts ADC noise.
    if(hasFilter_) normalized=uint16_t((uint32_t(normalized)*3U+filtered_[i]+2U)/4U);
    filtered_[i]=normalized;
    f.norm[i]=normalized;
    if(normalized>=290) {
      ++f.active;
      total+=normalized;
      if(i==0 || f.norm[i-1]<290) ++f.groups;
    }
  }
  hasFilter_=true;
  f.seen=(f.active>0 && total>=390);
  f.confidence=uint16_t(total>=5000?1000:total/5);
  f.leftEdge=(f.norm[0]>=390 || f.norm[1]>=390);
  f.rightEdge=(f.norm[12]>=390 || f.norm[13]>=390);
  f.center=(f.norm[5]>=390 || f.norm[6]>=390 ||
            f.norm[7]>=390 || f.norm[8]>=390);
  f.fullMarker=(f.active>=13);
  f.junction=!f.fullMarker && f.active>=5 &&
    ((f.leftEdge && f.rightEdge) ||
     (f.center && (f.leftEdge || f.rightEdge) && f.active>=6));

  const int16_t oldPos=hasPosition_?lastPos_:0;
  int16_t best=oldPos;
  int32_t bestDistance=32767;
  // When a junction has separate blobs, do not average across both branches.
  for(uint8_t i=0;i<SENSOR_COUNT;) {
    if(f.norm[i]<290) {++i;continue;}
    int32_t weightSum=0,positionSum=0;
    while(i<SENSOR_COUNT && f.norm[i]>=290) {
      const uint16_t w=f.norm[i];
      weightSum+=w;
      positionSum+=int32_t(w)*(int32_t(i)*1000-6500);
      ++i;
    }
    if(weightSum==0) continue;
    const int16_t candidate=int16_t(positionSum/weightSum);
    const int32_t distance=abs(int32_t(candidate)-oldPos);
    if(distance<bestDistance) {bestDistance=distance;best=candidate;}
  }
  f.pos=f.seen?best:oldPos;
  if(f.seen && !f.junction && !f.fullMarker) {
    lastPos_=best;hasPosition_=true;
  }
}
}
